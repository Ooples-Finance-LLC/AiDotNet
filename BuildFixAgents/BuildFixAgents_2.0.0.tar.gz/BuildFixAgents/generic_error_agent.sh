#!/bin/bash

# Generic Error Resolution Agent
# Can be specialized for any error pattern based on configuration

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$SCRIPT_DIR/agent_coordination.log"
COORDINATION_FILE="$SCRIPT_DIR/AGENT_COORDINATION.md"
BUILD_OUTPUT_FILE="$SCRIPT_DIR/build_output.txt"

# Agent configuration (passed as arguments)
AGENT_ID="${1:-generic_agent}"
AGENT_SPEC_FILE="${2:-$SCRIPT_DIR/agent_specifications.json}"
TARGET_ERRORS="${3:-}"

# Initialize logging
log_message() {
    local message="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $AGENT_ID: $message" | tee -a "$LOG_FILE"
}

# Load agent configuration
load_agent_config() {
    log_message "Loading agent configuration..."
    
    if [[ ! -f "$AGENT_SPEC_FILE" ]]; then
        log_message "ERROR: Agent specification file not found"
        exit 1
    fi
    
    # Extract this agent's configuration
    AGENT_NAME=$(grep -A10 "\"agent_id\": \"$AGENT_ID\"" "$AGENT_SPEC_FILE" | grep '"name":' | cut -d'"' -f4 || echo "generic_agent")
    SPECIALIZATION=$(grep -A10 "\"agent_id\": \"$AGENT_ID\"" "$AGENT_SPEC_FILE" | grep '"specialization":' | cut -d'"' -f4 || echo "general")
    
    if [[ -z "$TARGET_ERRORS" ]]; then
        TARGET_ERRORS=$(grep -A10 "\"agent_id\": \"$AGENT_ID\"" "$AGENT_SPEC_FILE" | grep -A1 '"target_errors":' | grep -oE 'CS[0-9]{4}' | tr '\n' ' ')
    fi
    
    log_message "Agent: $AGENT_NAME"
    log_message "Specialization: $SPECIALIZATION"
    log_message "Target errors: $TARGET_ERRORS"
}

# File locking functions
claim_file() {
    local file_path="$1"
    bash "$SCRIPT_DIR/build_checker_agent.sh" claim "$AGENT_ID" "$file_path"
}

release_file() {
    local file_path="$1"
    bash "$SCRIPT_DIR/build_checker_agent.sh" release "$AGENT_ID" "$file_path"
}

# Find files with target errors
find_error_files() {
    local error_codes="$1"
    local files=()
    
    for code in $error_codes; do
        local error_files=$(grep "error $code" "$BUILD_OUTPUT_FILE" | cut -d'(' -f1 | sort -u)
        for file in $error_files; do
            files+=("$file")
        done
    done
    
    # Return unique files
    printf '%s\n' "${files[@]}" | sort -u
}

# Generic error resolution strategies
resolve_duplicate_definitions() {
    local file_path="$1"
    local error_code="$2"
    
    log_message "Resolving duplicate definitions in $file_path"
    
    case "$error_code" in
        "CS0101")
            # Duplicate class/interface in namespace
            log_message "Analyzing duplicate type definitions..."
            # Strategy: Find and remove duplicate class definitions
            ;;
        "CS0111")
            # Duplicate member definition
            log_message "Analyzing duplicate member definitions..."
            # Strategy: Find and remove duplicate methods/properties
            ;;
        "CS0102")
            # Duplicate type in namespace
            log_message "Analyzing duplicate type conflicts..."
            # Strategy: Rename or remove conflicting types
            ;;
    esac
}

resolve_type_resolution() {
    local file_path="$1"
    local error_code="$2"
    
    log_message "Resolving type resolution issues in $file_path"
    
    case "$error_code" in
        "CS0246")
            # Type or namespace not found
            log_message "Analyzing missing type references..."
            # Strategy: Add using statements or fully qualify types
            ;;
        "CS0234")
            # Type or namespace does not exist
            log_message "Analyzing namespace issues..."
            # Strategy: Check references and namespaces
            ;;
        "CS0104")
            # Ambiguous reference
            log_message "Resolving ambiguous references..."
            # Strategy: Use fully qualified names or aliases
            ;;
    esac
}

resolve_interface_implementation() {
    local file_path="$1"
    local error_code="$2"
    
    log_message "Resolving interface implementation issues in $file_path"
    
    case "$error_code" in
        "CS0535")
            # Does not implement interface member
            log_message "Implementing missing interface members..."
            # Strategy: Add missing method implementations
            ;;
        "CS0738")
            # Does not implement interface member with same return type
            log_message "Fixing interface implementation signatures..."
            # Strategy: Correct method signatures
            ;;
    esac
}

resolve_inheritance_override() {
    local file_path="$1"
    local error_code="$2"
    
    log_message "Resolving inheritance/override issues in $file_path"
    
    case "$error_code" in
        "CS0115")
            # No suitable method found to override
            log_message "Fixing override signatures..."
            # Strategy: Match base class signatures
            ;;
        "CS0534")
            # Does not implement inherited abstract member
            log_message "Implementing abstract members..."
            # Strategy: Add abstract method implementations
            ;;
        "CS0462")
            # Inherited members have same signature
            log_message "Resolving inherited member conflicts..."
            # Strategy: Use explicit interface implementation
            ;;
    esac
}

resolve_generic_constraints() {
    local file_path="$1"
    local error_code="$2"
    
    log_message "Resolving generic constraint issues in $file_path"
    
    case "$error_code" in
        "CS0305")
            # Wrong number of type parameters
            log_message "Fixing generic type parameter count..."
            # Strategy: Adjust generic parameters
            ;;
        "CS0453")
            # Must be non-nullable value type
            log_message "Fixing nullable type constraints..."
            # Strategy: Add struct constraint or change type
            ;;
        "CS8377")
            # Type must be a value type (INumber issue)
            log_message "Removing INumber constraints for .NET Framework..."
            # Strategy: Replace with compatible constraints
            ;;
    esac
}

# Main resolution dispatcher
resolve_error() {
    local file_path="$1"
    local error_code="$2"
    
    # Dispatch to appropriate resolution strategy based on specialization
    case "$SPECIALIZATION" in
        "definition_conflicts")
            resolve_duplicate_definitions "$file_path" "$error_code"
            ;;
        "type_resolution")
            resolve_type_resolution "$file_path" "$error_code"
            ;;
        "interface_implementation")
            resolve_interface_implementation "$file_path" "$error_code"
            ;;
        "inheritance_override")
            resolve_inheritance_override "$file_path" "$error_code"
            ;;
        "generic_constraints")
            resolve_generic_constraints "$file_path" "$error_code"
            ;;
        *)
            log_message "WARNING: Unknown specialization $SPECIALIZATION"
            ;;
    esac
}

# Process assigned files
process_files() {
    local processed_count=0
    local files_modified=""
    
    # Find all files with our target errors
    local target_files=$(find_error_files "$TARGET_ERRORS")
    
    if [[ -z "$target_files" ]]; then
        log_message "No files found with target errors"
        return 0
    fi
    
    log_message "Found $(echo "$target_files" | wc -l) files to process"
    
    # Process each file
    while IFS= read -r file_path; do
        [[ -z "$file_path" ]] && continue
        
        # Try to claim the file
        if claim_file "$file_path"; then
            log_message "Processing $file_path"
            
            # Find specific errors in this file
            local file_errors=""
            for error_code in $TARGET_ERRORS; do
                if grep -q "error $error_code" "$BUILD_OUTPUT_FILE" | grep -q "^$file_path"; then
                    file_errors="$file_errors $error_code"
                fi
            done
            
            # Process each error type in the file
            for error_code in $file_errors; do
                resolve_error "$file_path" "$error_code"
            done
            
            # Release the file
            release_file "$file_path"
            
            files_modified="$files_modified $file_path"
            processed_count=$((processed_count + 1))
            
            # Update coordination file
            update_coordination_file "$file_path" "processed"
        else
            log_message "Could not claim $file_path - skipping"
        fi
        
        # Limit processing in one iteration
        [[ $processed_count -ge 5 ]] && break
        
    done <<< "$target_files"
    
    log_message "Processed $processed_count files"
    
    # Validate changes if any files were modified
    if [[ -n "$files_modified" ]]; then
        bash "$SCRIPT_DIR/build_checker_agent.sh" validate "$AGENT_ID" "$files_modified"
    fi
}

# Update coordination file with progress
update_coordination_file() {
    local file_path="$1"
    local status="$2"
    
    {
        echo ""
        echo "## $AGENT_ID Progress Update - $(date '+%Y-%m-%d %H:%M:%S')"
        echo "- File: $file_path"
        echo "- Status: $status"
        echo "- Specialization: $SPECIALIZATION"
    } >> "$COORDINATION_FILE"
}

# Main execution
main() {
    log_message "=== GENERIC ERROR AGENT STARTING ==="
    
    # Load configuration
    load_agent_config
    
    # Process files
    process_files
    
    log_message "=== GENERIC ERROR AGENT COMPLETE ==="
}

# Execute
main