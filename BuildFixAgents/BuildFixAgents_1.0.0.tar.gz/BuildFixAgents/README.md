# Multi-Agent Build Fix System

A self-contained, intelligent system for automatically fixing C# build errors using multiple specialized agents.

## 🚀 Quick Start

```bash
# From your project root (where .csproj file is located):
./BuildFixAgents/run_build_fix.sh analyze   # Analyze errors
./BuildFixAgents/run_build_fix.sh fix       # Fix errors automatically
```

## 📁 Directory Structure

```
BuildFixAgents/
├── run_build_fix.sh              # Main launcher script
├── generic_build_analyzer.sh     # Dynamic error analyzer
├── generic_error_agent.sh        # Flexible agent template
├── generic_agent_coordinator.sh  # Agent orchestrator
├── logs/                         # Build outputs and logs
│   ├── agent_coordination.log
│   └── build_output.txt
├── state/                        # System state files
│   ├── error_analysis.json
│   ├── agent_specifications.json
│   └── AGENT_COORDINATION.md
└── README.md                     # This file
```

## 🎯 Features

- **Automatic Error Detection**: Analyzes all build errors and categorizes them
- **Dynamic Agent Creation**: Creates specialized agents based on error patterns
- **Parallel Processing**: Multiple agents work simultaneously
- **Safe Operations**: File locking prevents conflicts
- **Progress Tracking**: Real-time monitoring of fixes
- **Resumable**: Can resume from interruptions

## 📋 Commands

### Analyze Build Errors
```bash
./BuildFixAgents/run_build_fix.sh analyze
```
Scans your project and categorizes all build errors.

### Fix Errors (Execute Mode)
```bash
./BuildFixAgents/run_build_fix.sh fix
```
Deploys agents to automatically fix detected errors.

### Simulate Fixes
```bash
./BuildFixAgents/run_build_fix.sh simulate
```
Shows what would be fixed without making changes.

### Check Status
```bash
./BuildFixAgents/run_build_fix.sh status
```
Shows current build status and agent activity.

### Resume Previous Session
```bash
./BuildFixAgents/run_build_fix.sh resume
```
Continues from where the system left off.

### Clean Up
```bash
./BuildFixAgents/run_build_fix.sh clean
```
Removes temporary files and archives logs.

## 🔧 How It Works

1. **Analysis Phase**: The system runs your build and analyzes all errors
2. **Categorization**: Errors are grouped into categories (duplicates, missing types, etc.)
3. **Agent Creation**: Specialized agents are created for each error category
4. **Execution**: Agents work in parallel to fix their assigned errors
5. **Validation**: Each fix is validated to ensure it reduces errors

## 📊 Error Categories

The system automatically detects and handles:
- **Definition Conflicts**: Duplicate classes, methods, or members
- **Type Resolution**: Missing types, ambiguous references
- **Interface Implementation**: Missing or incorrect interface members
- **Inheritance Issues**: Override mismatches, abstract members
- **Generic Constraints**: Type parameter problems, nullable issues

## 🛠️ Deployment

### Option 1: Copy to Any C# Project
```bash
# Copy the entire BuildFixAgents folder to your project
cp -r BuildFixAgents /path/to/your/project/

# Run from your project directory
cd /path/to/your/project
./BuildFixAgents/run_build_fix.sh analyze
./BuildFixAgents/run_build_fix.sh fix
```

### Option 2: Run from Current Location
```bash
# The system automatically detects the project root
cd /path/to/AiDotNet
./BuildFixAgents/run_build_fix.sh fix
```

## 📈 Example Output

```
═══ Running Error Analysis ═══
✓ Analysis complete

Error Categories Found:
  interface implementation:      324 errors
  type resolution:              90 errors
  definition conflicts:         36 errors
  inheritance override:         36 errors

═══ Running Build Fix (execute mode) ═══
Deploying interface_implementation_specialist (workload: 324 errors)
Deploying type_resolution_specialist (workload: 90 errors)
Deploying definition_conflicts_specialist (workload: 36 errors)

Active agents: 3
All agents completed for iteration 1
Current error count: 156
BUILD SUCCESSFUL! All errors resolved.
```

## 🔍 Monitoring

View real-time progress:
```bash
# Watch agent activity
tail -f BuildFixAgents/logs/agent_coordination.log

# Check error analysis
cat BuildFixAgents/state/error_analysis.json

# View agent specifications
cat BuildFixAgents/state/agent_specifications.json
```

## ⚙️ Advanced Usage

### Use Legacy System
```bash
./BuildFixAgents/run_build_fix.sh fix --system legacy
```

### Verbose Logging
```bash
./BuildFixAgents/run_build_fix.sh fix --verbose
```

## 🐛 Troubleshooting

### Agents Not Starting
- Check `logs/agent_coordination.log` for errors
- Ensure scripts have execute permissions: `chmod +x BuildFixAgents/*.sh`

### Build Still Failing
- Run `status` to see remaining errors
- Check if new error types need handling
- Some errors may require manual intervention

### System Stuck
- Run `clean` to remove locks
- Check for zombie processes: `ps aux | grep agent`

## 📝 License

This system is part of the AiDotNet project.